# Madi Music — Android

Offline-first Android music player built with Kotlin, Jetpack Compose and AndroidX Media3.

## Features in this starter build
- Dark premium interface with purple accents and Arabic/English track labels.
- 16-track catalog across five artists.
- Search and artist filtering, favorites, previous/play/next controls.
- MediaSession playback service for background playback and system media controls.
- Audio is bundled into the APK during the GitHub Actions build; playback needs no internet connection.

## Build from GitHub on a phone
The workflow is provided separately as `android.yml`. Add it to your repository at `.github/workflows/android.yml`.
Create a GitHub Release and upload these seven assets with their exact filenames:
- `MadiMusic-Android-Source.zip`
- `01-Cheb-Akil.zip`
- `02-Cheb-MoMo-A.zip`
- `03-Cheb-MoMo-B.zip`
- `05-Aljundi.7z`
- `06-Rafea.7z`
- `07-Colomby.7z`
Then open Actions and run **Build Madi Music APK**. Download the resulting artifact named `Madi-Music-debug-APK`.

The APK has not yet been built or tested on a physical device. Verify the GitHub Actions build before installing. Confirm you have permission to use and redistribute the recordings.
